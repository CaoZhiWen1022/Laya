import { ExportData, exportData, exportPointData, exportQuDianData } from "../ExportData";
import { GameEventManager, GameEventType } from "../GameEventManager";
import { MapMgr } from "../MapMgr";
import { ResConfig } from "../ResConfig";
import UI_MainPanel from "../fgui/Package1/UI_MainPanel";
import UI_PointCom from "../fgui/Package1/UI_PointCom";
import { CloudInfoCom } from "./CloudInfoCom";
import { MapCom } from "./MapCom";
import { MapUIMgr } from "./MapUIMgr";
import { UI_PointComExt } from "./UI_PointComExt";

export class MainPanel {
    ui: UI_MainPanel;
    constructor() {
        this.ui = UI_MainPanel.createInstance();
        this.ui.makeFullScreen();
        fgui.GRoot.inst.addChild(this.ui);
        this.ui.m_map.m_mapImg.url = ResConfig.getMapImgUrl(MapMgr.ins.mapId);


        this.ui.m_ls_walkEditTF.onClick(this, this.onClickWalkTF)
        this.ui.m_ls_pointEditTF.onClick(this, this.onClickPointTF)
        this.ui.m_ls_pointEditTF.selectedIndex = 0;
        this.ui.m_ls_walkEditTF.selectedIndex = 0;
        this.ui.m_ls_area.onClick(this, this.onclickArea)
        this.ui.m_ls_area.selectedIndex = 0;
        this.ui.m_createQuDian.onClick(this, this.onCreateQuDian)

        this.ui.m_c_func.on(fgui.Events.STATE_CHANGED, this, this.onFuncChange);

        this.ui.m_export.onClick(this, this.onExport)
        this.ui.m_exportPoint.onClick(this, this.onExportPoint)
        this.ui.m_exportPoint_2.onClick(this, this.onExportPoint_2)

        this.initMap()
    }

    async initMap() {
        MapUIMgr.ins.mapCom = new MapCom(this.ui.m_map);
        MapUIMgr.ins.cloudInfoCom = new CloudInfoCom(this.ui.m_cloudInfo);
        await MapUIMgr.ins.mapCom.init();
        this.ui.m_building.visible = false;
        GameEventManager.event(GameEventType.areaIndexChange)
    }

    onFuncChange() {
        let index = this.ui.m_c_func.selectedIndex;
        [
            this.ui.m_map.m_gridLayer,
            this.ui.m_map.m_areaLayer,
            this.ui.m_map.m_pointLayer,
            this.ui.m_map.m_cloudLayer,
            this.ui.m_map.m_quDianClick,
            this.ui.m_map.m_quDianLayer,
        ].forEach(ui => ui.visible = false)
        switch (index) {
            case FuncType._划分区域_:
                this.ui.m_map.m_areaLayer.visible = true;
                break;
            case FuncType._编辑行走区域_:
                this.ui.m_map.m_gridLayer.visible = true;
                break;
            case FuncType._点位信息_:
                this.ui.m_map.m_pointLayer.visible = true;
                break;
            case FuncType._云信息_:
                this.ui.m_map.m_cloudLayer.visible = true;
                break;
            case FuncType._取点信息_:
                this.ui.m_map.m_quDianClick.visible = true;
                this.ui.m_map.m_quDianLayer.visible = true;
                break;
            default:
                break;
        }
    }

    onClickWalkTF() {
        let isTrue = this.ui.m_ls_walkEditTF.selectedIndex == 0;
        MapUIMgr.ins.walkEdit_isTrue = isTrue;
    }

    onClickPointTF() {
        let isTrue = this.ui.m_ls_pointEditTF.selectedIndex == 0;
        MapUIMgr.ins.pointEdit_isTrue = isTrue;
    }

    onclickArea() {
        MapUIMgr.ins.curSeleArea = this.ui.m_ls_area.selectedIndex + 1;
    }

    onCreateQuDian() {
        let str = this.ui.m_quDianInput.text;
        if (str.length > 0) {
            let strList = str.split("|");
            //检测一下
            let isCheck = strList.filter(v => v.split("#").length != 4).length != 0;
            if (isCheck) {
                console.log("格式不正确");
                return;
            }
            strList.forEach(v => {
                let [px, py, offx, offy] = v.split("#") as any;
                px = Number(px);
                py = Number(py);
                offx = Number(offx);
                offy = Number(offy);
                //计算实际xy
                let grid = MapUIMgr.ins.quDianGrids.find(grid => grid.px == px && grid.py == py);
                let x = grid.startX + (grid.endX - grid.startX) / 2 + offx;
                let y = grid.startY + (grid.endY - grid.startY) / 2 + offy;
                //创建一个点
                let pointCom = UI_PointCom.createInstance() as UI_PointComExt;
                MapUIMgr.ins.mapCom.ui.m_quDianLayer.addChild(pointCom);
                pointCom.init(Number(x), Number(y));
            })
        }
    }

    onExport() {
        exportData();
    }

    onExportPoint() {
        exportPointData()
    }

    onExportPoint_2() {
        exportQuDianData()
    }
}

enum FuncType {
    _null_ = 0,
    _划分区域_,
    _编辑行走区域_,
    _点位信息_,
    _云信息_,
    _取点信息_,
}