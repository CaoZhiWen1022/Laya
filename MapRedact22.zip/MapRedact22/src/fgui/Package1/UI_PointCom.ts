/** This is an automatically generated class by FairyGUI. Please do not modify it. **/

export default class UI_PointCom extends fgui.GComponent {

	public m_point:fgui.GGraph;
	public m_index:fgui.GTextField;
	public static URL:string = "ui://1d2nl1i7h88fh";

	public static createInstance():UI_PointCom {
		return <UI_PointCom>(fgui.UIPackage.createObject("Package1", "PointCom"));
	}

	protected onConstruct():void {
		this.m_point = <fgui.GGraph>(this.getChildAt(0));
		this.m_index = <fgui.GTextField>(this.getChildAt(1));
	}
}