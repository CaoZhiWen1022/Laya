import UI_PointCom from "../fgui/Package1/UI_PointCom";
import UI_QuDianInfo from "../fgui/Package1/UI_QuDianInfo";
import { GameEventManager, GameEventType } from "../GameEventManager";
import { MapUIMgr } from "./MapUIMgr";
import { QuDianGrid } from "./QuDianGrid";

export class UI_PointComExt extends UI_PointCom {

    static infoCom: UI_QuDianInfo;

    grid: QuDianGrid;
    offX: number;
    offY: number;
    index: number;
    init(x, y) {
        this.x = x;
        this.y = y;
        this.grid = MapUIMgr.ins.quDianGrids.find(grid => grid.startX <= x && grid.endX >= x && grid.startY <= y && grid.endY >= y);

        let gridConX = this.grid.startX + (this.grid.endX - this.grid.startX) / 2
        let gridConY = this.grid.startY + (this.grid.endY - this.grid.startY) / 2
        this.offX = x - gridConX;
        this.offY = y - gridConY;
        this.onClick(this, this.clickThis);
        MapUIMgr.ins.quDianUiComS.push(this);
        this.index = MapUIMgr.ins.quDianUIIndex;
        this.m_index.text = this.index.toString();
        MapUIMgr.ins.quDianUIIndex++;
    }

    clickThis() {
        let com = UI_PointComExt.infoCom || UI_QuDianInfo.createInstance();
        let str = "编号:\t" + this.index;
        str += "\npx:\t" + this.grid.px.toFixed(0);
        str += "\npy:\t" + this.grid.py.toFixed(0);
        str += "\nx:\t" + this.x.toFixed(0);
        str += "\ny:\t" + this.y.toFixed(0);
        str += "\noffx:\t" + this.offX.toFixed(0);
        str += "\noffy:\t" + this.offY.toFixed(0);
        com.m_info.text = str;
        com.m_del.displayObject.offAll("click");
        com.m_del.onClick(this, () => {
            this.dispose();
            fgui.GRoot.inst.hidePopup(com);
        });
        fgui.GRoot.inst.showPopup(com);
    }

    dispose(): void {
        super.dispose();
        MapUIMgr.ins.quDianUiComS.splice(MapUIMgr.ins.quDianUiComS.indexOf(this), 1);
    }
}