import Package1Binder from "../fgui/Package1/Package1Binder";
import { UI_PointComExt } from "./UI_PointComExt";

export default class Package1BinderExt extends Package1Binder {
	public static bindAll(): void {
		super.bindAll();
		[
			UI_PointComExt
		].forEach(cls => fgui.UIObjectFactory.setExtension(cls.URL, cls))
	}
}