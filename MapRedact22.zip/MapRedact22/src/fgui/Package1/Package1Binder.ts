/** This is an automatically generated class by FairyGUI. Please do not modify it. **/

import UI_cloudInfo from "./UI_cloudInfo";
import UI_cloud from "./UI_cloud";
import UI_MainPanel from "./UI_MainPanel";
import UI_MapCom from "./UI_MapCom";
import UI_grid from "./UI_grid";
import UI_area from "./UI_area";
import UI_PointCom from "./UI_PointCom";
import UI_QuDianInfo from "./UI_QuDianInfo";
import UI_start from "./UI_start";

export default class Package1Binder {
	public static bindAll():void {
		fgui.UIObjectFactory.setExtension(UI_cloudInfo.URL, UI_cloudInfo);
		fgui.UIObjectFactory.setExtension(UI_cloud.URL, UI_cloud);
		fgui.UIObjectFactory.setExtension(UI_MainPanel.URL, UI_MainPanel);
		fgui.UIObjectFactory.setExtension(UI_MapCom.URL, UI_MapCom);
		fgui.UIObjectFactory.setExtension(UI_grid.URL, UI_grid);
		fgui.UIObjectFactory.setExtension(UI_area.URL, UI_area);
		fgui.UIObjectFactory.setExtension(UI_PointCom.URL, UI_PointCom);
		fgui.UIObjectFactory.setExtension(UI_QuDianInfo.URL, UI_QuDianInfo);
		fgui.UIObjectFactory.setExtension(UI_start.URL, UI_start);
	}
}