/** This is an automatically generated class by FairyGUI. Please do not modify it. **/

export default class UI_MapCom extends fgui.GComponent {

	public m_button:fgui.Controller;
	public m_wh:fgui.GGraph;
	public m_mapImg:fgui.GLoader;
	public m_gridLayer:fgui.GComponent;
	public m_areaLayer:fgui.GComponent;
	public m_pointLayer:fgui.GComponent;
	public m_cloudLayer:fgui.GComponent;
	public m_quDianClick:fgui.GComponent;
	public m_quDianLayer:fgui.GComponent;
	public static URL:string = "ui://1d2nl1i7d8vm5";

	public static createInstance():UI_MapCom {
		return <UI_MapCom>(fgui.UIPackage.createObject("Package1", "MapCom"));
	}

	protected onConstruct():void {
		this.m_button = this.getControllerAt(0);
		this.m_wh = <fgui.GGraph>(this.getChildAt(0));
		this.m_mapImg = <fgui.GLoader>(this.getChildAt(1));
		this.m_gridLayer = <fgui.GComponent>(this.getChildAt(2));
		this.m_areaLayer = <fgui.GComponent>(this.getChildAt(3));
		this.m_pointLayer = <fgui.GComponent>(this.getChildAt(4));
		this.m_cloudLayer = <fgui.GComponent>(this.getChildAt(5));
		this.m_quDianClick = <fgui.GComponent>(this.getChildAt(6));
		this.m_quDianLayer = <fgui.GComponent>(this.getChildAt(7));
	}
}