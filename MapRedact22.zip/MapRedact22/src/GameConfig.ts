/*
* 游戏初始化配置;
*/
export default class GameConfig {
    //语言版本控制
    static LanguageVersion_ES_ES: string = "es_es";
    static LanguageVersion_ZH_CN: string = "zh_cn";
    static LanguageVersion_ZH_HK: string = "zh-hk";

    static width: number = 1920;
    static height: number = 1080;
    static scaleMode: string = Laya.Stage.SCALE_FIXED_AUTO;
    static screenMode: string = "none";
    static alignV: string = "top";
    static alignH: string = "left";
    static startScene: any = "test/TestScene.scene";
    static sceneRoot: string = "";
    static language: string = GameConfig.LanguageVersion_ZH_CN;                  //当前语言环境--游戏刚启动时的基本提示用--具体文本配在MyGame中
    static debug: boolean = false;
    static guideValid: boolean = false;                 //true:引导开启  false:关闭引导
    static debugMsg: Number = 3;                        //0:不使用调试信息 1:使用调试信息,但不联网	2:使用调试信息,联网 3:聊天命令
    static stat: boolean = false;                        //true:显示调试信息, false:不显示
    static isShowLog: boolean = true;                   //由于log会占用性能消耗 所以添加log开关
    static physicsDebug: boolean = false;
    static exportSceneToJson: boolean = true;
    static isUseSdk: number = 2;                        //0:不使用sdk  1:使用sdk  2:智能判断
    //static buildVersion: string = "BUILD_VERSION";
    static iosVerify: boolean = false;
    static iosVerifyOther: boolean = false;          //马甲包用
    static andVerify: boolean = false;               //android提审和ios提审需求不一样 所以要分开两个标记
    static opserview: number = 0;
    constructor() { }
    static init() {
    }
}
GameConfig.init();