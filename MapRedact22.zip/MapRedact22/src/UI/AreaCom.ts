import { GameEventManager, GameEventType } from "../GameEventManager";
import { MapMgr } from "../MapMgr";
import UI_area from "../fgui/Package1/UI_area";
import { MapUIMgr } from "./MapUIMgr";

export class AreaCom {

    static index = 1;

    ui: UI_area;

    s_id: string;
    constructor(px: number, py: number) {
        this.ui = UI_area.createInstance();
        this.ui.x = px * MapMgr.ins.areaWH;
        this.ui.y = py * MapMgr.ins.areaWH;
        this.ui.onClick(this, this.setArea)

        //s_id命名：由mapId+"_"+index组成 index由1自增
        this.s_id = MapMgr.ins.mapId + "_" + AreaCom.index;
        AreaCom.index++;

        GameEventManager.on(GameEventType.areaIndexChange, this, this.update)
    }

    setArea() {
        let curAreas = MapMgr.ins.areaMap.get(MapUIMgr.ins.curSeleArea) || [];
        if (curAreas.indexOf(this.s_id) != -1) {
            curAreas = curAreas.filter(v => v != this.s_id);
        } else {
            curAreas.push(this.s_id);
        }
        MapMgr.ins.areaMap.set(MapUIMgr.ins.curSeleArea, curAreas);
        this.update();
    }

    update() {
        let curAreas = MapMgr.ins.areaMap.get(MapUIMgr.ins.curSeleArea) || [];
        if (curAreas.indexOf(this.s_id) != -1) {
            this.ui.m_a.color = MapUIMgr.ins.areaColorMap;
        } else {
            this.ui.m_a.color = MapUIMgr.ins.areaDefaultColor;
        }
    }
}