import { GameEventManager, GameEventType } from "../GameEventManager";
import { MOUSEMGR } from "../MOUSEMGR";
import { MapMgr } from "../MapMgr";
import { sleep_frame } from "../WaitDelay";
import UI_MapCom from "../fgui/Package1/UI_MapCom";
import UI_PointCom from "../fgui/Package1/UI_PointCom";
import { AreaCom } from "./AreaCom";
import { CloudCom } from "./CloudCom";
import { GridCom } from "./GridCom";
import { MapUIMgr } from "./MapUIMgr";
import { PointGridCom } from "./PointGridCom";
import { QuDianGrid } from "./QuDianGrid";
import { UI_PointComExt } from "./UI_PointComExt";

export class MapCom {

    ui: UI_MapCom;

    constructor(ui: UI_MapCom) {
        this.ui = ui;
        this.ui.scrollPane.mouseWheelEnabled = false
        this.ui.m_wh.width = MapMgr.ins.mapwidth;
        this.ui.m_wh.height = MapMgr.ins.mapheight;

        this.ui.m_quDianClick.width = MapMgr.ins.mapwidth;
        this.ui.m_quDianClick.height = MapMgr.ins.mapheight;
        this.ui.m_quDianClick.onClick(this, this.onQuDianClick);

        GameEventManager.on(GameEventType.mouseWheel, this, this.onMouseWheel);
        GameEventManager.on(GameEventType.onkeydown, this, this.onKey);
        GameEventManager.on(GameEventType.onkeyup, this, this.onKey);
    }

    async init() {
        await this.initGrid();
        await this.initArea();
        await this.initGridPoint();
        await this.initCloud();
        await this.initGridPoint();
        this.initQuDianGrid()
    }

    /** 初始化网格 */
    async initGrid() {
        let gridWH = MapMgr.ins.gridWH;
        let mapwidth = MapMgr.ins.mapwidth;
        let mapheight = MapMgr.ins.mapheight;
        let row = Math.ceil(mapheight / gridWH);
        let col = Math.ceil(mapwidth / gridWH);
        let index = 0;
        for (let i = 0; i < row; i++) {
            for (let j = 0; j < col; j++) {
                let grid = new GridCom(j, i)
                this.ui.m_gridLayer.addChild(grid.ui);
                MapUIMgr.ins.grids.push(grid);
                index++;
                if (index % 400 == 0) await sleep_frame(1);
            }
        }
    }

    /** 初始化网格点位 */
    async initGridPoint() {
        let gridWH = MapMgr.ins.gridWH;
        let mapwidth = MapMgr.ins.mapwidth;
        let mapheight = MapMgr.ins.mapheight;
        let row = Math.ceil(mapheight / gridWH);
        let col = Math.ceil(mapwidth / gridWH);
        let index = 0;
        for (let i = 0; i < row; i++) {
            for (let j = 0; j < col; j++) {
                let grid = new PointGridCom(j, i)
                this.ui.m_pointLayer.addChild(grid.ui);
                MapUIMgr.ins.pointGrids.push(grid);
                index++;
                if (index % 400 == 0) await sleep_frame(1);
            }
        }
    }

    /** 初始化网格点位 */
    initQuDianGrid() {
        let gridWH = MapMgr.ins.gridWH;
        let mapwidth = MapMgr.ins.mapwidth;
        let mapheight = MapMgr.ins.mapheight;
        let row = Math.ceil(mapheight / gridWH);
        let col = Math.ceil(mapwidth / gridWH);
        let index = 0;
        for (let i = 0; i < row; i++) {
            for (let j = 0; j < col; j++) {
                let grid = new QuDianGrid(j, i)
                MapUIMgr.ins.quDianGrids.push(grid);
            }
        }
    }

    /** 初始化区域编辑 */
    async initArea() {
        let areaWH = MapMgr.ins.areaWH;
        let mapwidth = MapMgr.ins.mapwidth;
        let mapheight = MapMgr.ins.mapheight;
        let row = Math.ceil(mapheight / areaWH);
        let col = Math.ceil(mapwidth / areaWH);
        let index = 0;
        for (let i = 0; i < row; i++) {
            for (let j = 0; j < col; j++) {
                let area = new AreaCom(j, i)
                this.ui.m_areaLayer.addChild(area.ui);
                index++;
                if (index % 400 == 0) await sleep_frame(1);
            }
        }
    }


    /** 初始化云 */
    async initCloud() {
        let areaWH = MapMgr.ins.areaWH;
        let mapwidth = MapMgr.ins.mapwidth;
        let mapheight = MapMgr.ins.mapheight;
        let row = Math.ceil(mapheight / areaWH);
        let col = Math.ceil(mapwidth / areaWH);
        let index = 0;
        for (let i = 0; i < row; i++) {
            for (let j = 0; j < col; j++) {
                let area = new CloudCom(j, i)
                this.ui.m_cloudLayer.addChild(area.ui);
                index++;
                if (index % 400 == 0) await sleep_frame(1);
            }
        }
    }

    onMouseWheel(delta: number) {
        if (!MOUSEMGR.ins.isKeyDwon(17)) return;
        MapUIMgr.ins.mapComScale += delta > 0 ? 0.01 : -0.01;
        MapUIMgr.ins.mapComScale = Math.max(0.1, Math.min(2, MapUIMgr.ins.mapComScale));
        this.setScale(MapUIMgr.ins.mapComScale);
    }

    setScale(scale: number) {
        let W = MapMgr.ins.mapwidth * scale;
        let H = MapMgr.ins.mapheight * scale;
        this.ui.m_wh.width = W;
        this.ui.m_wh.height = H;
        this.ui.m_mapImg.setScale(scale, scale);
        this.ui.m_gridLayer.setScale(scale, scale);
        this.ui.m_areaLayer.setScale(scale, scale);
        this.ui.m_quDianClick.setScale(scale, scale);
        this.ui.m_quDianLayer.setScale(scale, scale);
    }

    onKey() {
        if (!MOUSEMGR.ins.isKeyDwon(17)) {
            this.ui.scrollPane.touchEffect = true;
        } else {
            this.ui.scrollPane.touchEffect = false;
        }
    }

    onQuDianClick(event: Laya.Event) {
        if (MOUSEMGR.ins.isKeyDwon(17)) {
            //创建一个点
            let pointCom = UI_PointCom.createInstance() as UI_PointComExt;
            let xy = { x: Laya.stage.mouseX - pointCom.width / 2 * MapUIMgr.ins.mapComScale, y: Laya.stage.mouseY - pointCom.height / 2 * MapUIMgr.ins.mapComScale };
            let mapXY = this.ui.m_quDianClick.globalToLocal(xy.x, xy.y)
            this.ui.m_quDianLayer.addChild(pointCom);
            pointCom.init(mapXY.x, mapXY.y);
        }
    }
}