import { MapMgr } from "./MapMgr";
import { MapUIMgr } from "./UI/MapUIMgr";
import { PointGridCom } from "./UI/PointGridCom";

export class ExportData {

    walkPoint: string[];//x_y;
    areaInfo: { areaIndex: number, area: string[] }[];
    cloudInfo: { cloudKey: string, offxy: { offx: number, offy: number } }[];
    gridWH: number;
    areaWH: number;
    mapWidth: number;
    mapHeight: number;
}

/** 导出数据 */
export function exportData() {
    let data: ExportData = new ExportData();
    data.areaWH = MapMgr.ins.areaWH;
    data.gridWH = MapMgr.ins.gridWH;
    data.mapWidth = MapMgr.ins.mapwidth;
    data.mapHeight = MapMgr.ins.mapheight;
    data.areaInfo = [];
    data.walkPoint = [];
    data.cloudInfo = [];

    //获取所有可行走块
    MapUIMgr.ins.grids.forEach(grid => {
        if (grid.ui.m_a.alpha == 0) data.walkPoint.push(grid.px + "_" + grid.py);
    })
    MapUIMgr.ins.cloudMap.forEach((v, k) => {
        if (v.offX != 0 || v.offy != 0) data.cloudInfo.push({ cloudKey: k, offxy: { offx: v.offX, offy: v.offy } });
    })
    MapMgr.ins.areaMap.forEach((v, k) => {
        data.areaInfo.push({ areaIndex: k, area: v })
    })

    let fileName = "MapData" + MapMgr.ins.mapId + ".json";
    window['downloadFile'](JSON.stringify(data), fileName, "text/plain")
}

export function exportPointData() {
    let data: { x, y }[] = [];
    //获取绿色点位导出
    MapUIMgr.ins.pointGrids.forEach(grid => {
        if (grid.ui.m_a.color == PointGridCom.greencolor) data.push({ x: grid.px, y: grid.py });
    })
    let str = "";
    data.forEach(info => {
        let index = data.indexOf(info)
        if (index != data.length - 1) str += info.x + "#" + info.y + ",";
        else str += info.x + "#" + info.y
    })
    let fileName = "MapDataPoint" + MapMgr.ins.mapId + ".txt";
    window['downloadFile'](str, fileName, "text/plain")
}

export function exportQuDianData() {
    let data: { px: number, py: number, offx: number, offy: number }[] = [];
    MapUIMgr.ins.quDianUiComS.forEach(com => {
        data.push({ px: com.grid.px, py: com.grid.py, offx: com.offX, offy: com.offY })
    })
    //格式 px#py#offx#offy|px#py#offx#offy
    let str = '';
    data.forEach(info => {
        let index = data.indexOf(info)
        str += info.px.toFixed(0) + "#" + info.py.toFixed(0) + "#" + info.offx.toFixed(0) + "#" + info.offy.toFixed(0)
        if (index != data.length - 1) str += "|";
    })
    let fileName = "MapDataQuDian.txt";
    window['downloadFile'](str, fileName, "text/plain")
}