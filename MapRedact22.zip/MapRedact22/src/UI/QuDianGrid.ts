import { MapMgr } from "../MapMgr";

export class QuDianGrid {

    px: number;
    py: number;

    startX: number;
    startY: number;
    endX: number;
    endY: number;
    constructor(px, py) {
        this.px = px;
        this.py = py;

        this.startX = px * MapMgr.ins.gridWH;
        this.startY = py * MapMgr.ins.gridWH;

        this.endX = this.startX + MapMgr.ins.gridWH;
        this.endY = this.startY + MapMgr.ins.gridWH;
    }
}