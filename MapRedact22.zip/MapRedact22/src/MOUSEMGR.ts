import { GameEventManager, GameEventType } from "./GameEventManager";

export class MOUSEMGR {

    public static get ins(): MOUSEMGR { return MOUSEMGR['_ins'] ? MOUSEMGR['_ins'] : MOUSEMGR['_ins'] = new MOUSEMGR() }

    /** 鼠标从按下到松开是否移动过 */
    isMouseMove = false;
    isMouseDown = false;

    keyDownMap: Map<number, boolean> = new Map<number, boolean>();
    constructor() {
        Laya.stage.on(Laya.Event.MOUSE_MOVE, this, this.mouseMove)
        Laya.stage.on(Laya.Event.MOUSE_DOWN, this, this.mouseDown)
        Laya.stage.on(Laya.Event.MOUSE_UP, this, this.mouseUp)


        Laya.stage.on(Laya.Event.KEY_UP, this, this.onkeyup);
        Laya.stage.on(Laya.Event.KEY_DOWN, this, this.onkeydown);

        Laya.stage.on(Laya.Event.MOUSE_WHEEL, this, this.mouseWheel)
    }

    mouseMove() {
        this.isMouseMove = true;
    }
    mouseDown() {
        this.isMouseMove = false;
        this.isMouseDown = true;
    }
    mouseUp() {
        this.isMouseDown = false;
    }

    onkeyup(e) {
        let key = e.keyCode
        this.keyDownMap.set(key, false)
        GameEventManager.event(GameEventType.onkeyup, key)
    }

    onkeydown(e) {
        let key = e.keyCode
        this.keyDownMap.set(key, true)
        console.log(key);
        GameEventManager.event(GameEventType.onkeydown, key)
    }

    mouseWheel(e) {
        GameEventManager.event(GameEventType.mouseWheel, e.delta)
    }

    isKeyDwon(key: number) {
        return this.keyDownMap.get(key);
    }
}