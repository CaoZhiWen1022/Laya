import { GameEventManager, GameEventType } from "../GameEventManager";
import UI_cloudInfo from "../fgui/Package1/UI_cloudInfo";
import { MapUIMgr } from "./MapUIMgr";

export class CloudInfoCom {

    ui: UI_cloudInfo;

    constructor(ui: UI_cloudInfo) {
        this.ui = ui;

        GameEventManager.on(GameEventType.onkeydown, this, this.onkeydown)
    }

    updataSele() {
        this.ui.m_px.text = MapUIMgr.ins.curSeleCloud.px + "";
        this.ui.m_py.text = MapUIMgr.ins.curSeleCloud.py + "";
        this.ui.m_x.text = MapUIMgr.ins.curSeleCloud.offX + "";
        this.ui.m_y.text = MapUIMgr.ins.curSeleCloud.offy + "";
    }

    onkeydown(key) {
        if (!this.ui.visible) return;
        if (!MapUIMgr.ins.curSeleCloud) return;
        //上下左右
        switch (key) {
            case 38:
                MapUIMgr.ins.curSeleCloud.updateOff(0, -1)
                break;
            case 40:
                MapUIMgr.ins.curSeleCloud.updateOff(0, 1)
                break;
            case 37:
                MapUIMgr.ins.curSeleCloud.updateOff(-1, 0)
                break;
            case 39:
                MapUIMgr.ins.curSeleCloud.updateOff(1, 0)
                break;
        }
        this.updataSele()
    }
}