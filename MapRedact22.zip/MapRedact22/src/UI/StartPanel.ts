import { ExportData } from "../ExportData";
import { MapMgr } from "../MapMgr";
import { ResConfig } from "../ResConfig";
import { ResLoadMgr } from "../ResLoadMgr";
import UI_start from "../fgui/Package1/UI_start";
import { MainPanel } from "./MainPanel";

export class StartPanel {
    ui: UI_start;
    constructor() {
        this.ui = UI_start.createInstance();
        this.ui.makeFullScreen();
        fgui.GRoot.inst.addChild(this.ui);
        this.ui.m_btn_start.onClick(this, this.onStartClick);

        this.ui.m_mapId.text = "1";
        this.ui.m_gridWH.text = "100";
    }

    async onStartClick() {

        let mapId = this.ui.m_mapId.text;
        let gridWH = this.ui.m_gridWH.text;
        //检测是否是数字
        if (isNaN(Number(mapId)) || isNaN(Number(gridWH))) {
            console.log("mapId is not a number");
            return;
        }
        if (Number(gridWH) <= 0) {
            console.log("gridWH is not a number");

        }
        let isContinue = this.ui.m_btn_continue.selected;
        if (isContinue) {
            let data: ExportData = await ResLoadMgr.Load(ResConfig.getJsonDataUrl(Number(mapId))) as any
            if (data) {
                let gwh = data.gridWH;
                if (gridWH != gwh.toString()) {
                    console.log("网格大小不匹配，以使用历史网格大小");
                    gridWH = gwh.toString();
                }
                MapMgr.ins.areaMap = new Map();
                data.areaInfo.forEach(info => {
                    MapMgr.ins.areaMap.set(info.areaIndex, info.area);
                })
                MapMgr.ins.walks = data.walkPoint;
                let cloudInfo = data.cloudInfo;
                if (cloudInfo) {
                    cloudInfo.forEach(v => {
                        MapMgr.ins.cloudInfo.set(v.cloudKey, { offX: v.offxy.offx, offy: v.offxy.offy })
                    })
                }
            } else {
                console.log("没有对应数据信息，重新构建");
            }
            let data1: { x, y }[] = await ResLoadMgr.Load(ResConfig.getJsonDataUrlPoint(Number(mapId))) as any
            if (data1) {
                data1.forEach(info => {
                    MapMgr.ins.pointGrids.push(info.x + "_" + info.y)
                })
            }
        }

        let res = await ResLoadMgr.Load(ResConfig.getMapImgUrl(Number(mapId)));
        if (res) {
            this.ui.dispose();
            MapMgr.ins.mapId = Number(mapId);
            MapMgr.ins.mapwidth = res.width;
            MapMgr.ins.mapheight = res.height;
            MapMgr.ins.gridWH = Number(gridWH);
            new MainPanel();
        } else {
            console.log("mapId is not exist");
        }
        console.log("start game");
    }
}