/** This is an automatically generated class by FairyGUI. Please do not modify it. **/

export default class UI_start extends fgui.GComponent {

	public m_btn_start:fgui.GButton;
	public m_mapId:fgui.GTextInput;
	public m_gridWH:fgui.GTextInput;
	public m_btn_continue:fgui.GButton;
	public static URL:string = "ui://1d2nl1i7qx2p0";

	public static createInstance():UI_start {
		return <UI_start>(fgui.UIPackage.createObject("Package1", "start"));
	}

	protected onConstruct():void {
		this.m_btn_start = <fgui.GButton>(this.getChildAt(2));
		this.m_mapId = <fgui.GTextInput>(this.getChildAt(5));
		this.m_gridWH = <fgui.GTextInput>(this.getChildAt(9));
		this.m_btn_continue = <fgui.GButton>(this.getChildAt(12));
	}
}