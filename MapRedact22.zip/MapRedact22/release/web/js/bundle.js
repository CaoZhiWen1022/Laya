(function () {
    'use strict';

    /*
    * 游戏初始化配置;
    */
    class GameConfig {
        constructor() { }
        static init() {
        }
    }
    //语言版本控制
    GameConfig.LanguageVersion_ES_ES = "es_es";
    GameConfig.LanguageVersion_ZH_CN = "zh_cn";
    GameConfig.LanguageVersion_ZH_HK = "zh-hk";
    GameConfig.width = 1920;
    GameConfig.height = 1080;
    GameConfig.scaleMode = Laya.Stage.SCALE_FIXED_AUTO;
    GameConfig.screenMode = "none";
    GameConfig.alignV = "top";
    GameConfig.alignH = "left";
    GameConfig.startScene = "test/TestScene.scene";
    GameConfig.sceneRoot = "";
    GameConfig.language = GameConfig.LanguageVersion_ZH_CN; //当前语言环境--游戏刚启动时的基本提示用--具体文本配在MyGame中
    GameConfig.debug = false;
    GameConfig.guideValid = false; //true:引导开启  false:关闭引导
    GameConfig.debugMsg = 3; //0:不使用调试信息 1:使用调试信息,但不联网	2:使用调试信息,联网 3:聊天命令
    GameConfig.stat = false; //true:显示调试信息, false:不显示
    GameConfig.isShowLog = true; //由于log会占用性能消耗 所以添加log开关
    GameConfig.physicsDebug = false;
    GameConfig.exportSceneToJson = true;
    GameConfig.isUseSdk = 2; //0:不使用sdk  1:使用sdk  2:智能判断
    //static buildVersion: string = "BUILD_VERSION";
    GameConfig.iosVerify = false;
    GameConfig.iosVerifyOther = false; //马甲包用
    GameConfig.andVerify = false; //android提审和ios提审需求不一样 所以要分开两个标记
    GameConfig.opserview = 0;
    GameConfig.init();
    //# sourceMappingURL=GameConfig.js.map

    class GameEventManager {
        static onMsg(MsgType, caller, listener, args = null) {
            var type = "messages.API" + MsgType;
            return GameEventManager.on(type, caller, listener, args);
        }
        static on(type, caller, listener, args = null) {
            return GameEventManager._Event.on(type, caller, listener, args);
        }
        static once(type, caller, listener, args = null) {
            return GameEventManager._Event.once(type, caller, listener, args);
        }
        static offMsg(MsgType, caller, listener, onceOnly = false) {
            var type = "messages.API" + MsgType;
            return GameEventManager.off(type, caller, listener, onceOnly);
        }
        static off(type, caller, listener, onceOnly = false) {
            return GameEventManager._Event.off(type, caller, listener, onceOnly);
        }
        static eventMsg(MsgType, data = null) {
            var type = "messages.API" + MsgType;
            return GameEventManager.event(type, data);
        }
        static event(type, data = null) {
            return GameEventManager._Event.event(type, data);
        }
        static offAllCaller(caller) {
            return GameEventManager._Event.offAllCaller(caller);
        }
    }
    GameEventManager._Event = new Laya.EventDispatcher();
    let Dispatch = GameEventManager;
    var GameEventType;
    (function (GameEventType) {
        GameEventType["ExploreMapContainerScroll"] = "ExploreMapContainerScroll";
        GameEventType["onkeydown"] = "onkeydown";
        GameEventType["onkeyup"] = "onkeyup";
        GameEventType["mouseWheel"] = "mouseWheel";
        GameEventType["areaIndexChange"] = "areaIndexChange";
    })(GameEventType || (GameEventType = {}));
    //# sourceMappingURL=GameEventManager.js.map

    class MOUSEMGR {
        constructor() {
            /** 鼠标从按下到松开是否移动过 */
            this.isMouseMove = false;
            this.isMouseDown = false;
            this.keyDownMap = new Map();
            Laya.stage.on(Laya.Event.MOUSE_MOVE, this, this.mouseMove);
            Laya.stage.on(Laya.Event.MOUSE_DOWN, this, this.mouseDown);
            Laya.stage.on(Laya.Event.MOUSE_UP, this, this.mouseUp);
            Laya.stage.on(Laya.Event.KEY_UP, this, this.onkeyup);
            Laya.stage.on(Laya.Event.KEY_DOWN, this, this.onkeydown);
            Laya.stage.on(Laya.Event.MOUSE_WHEEL, this, this.mouseWheel);
        }
        static get ins() { return MOUSEMGR['_ins'] ? MOUSEMGR['_ins'] : MOUSEMGR['_ins'] = new MOUSEMGR(); }
        mouseMove() {
            this.isMouseMove = true;
        }
        mouseDown() {
            this.isMouseMove = false;
            this.isMouseDown = true;
        }
        mouseUp() {
            this.isMouseDown = false;
        }
        onkeyup(e) {
            let key = e.keyCode;
            this.keyDownMap.set(key, false);
            GameEventManager.event(GameEventType.onkeyup, key);
        }
        onkeydown(e) {
            let key = e.keyCode;
            this.keyDownMap.set(key, true);
            console.log(key);
            GameEventManager.event(GameEventType.onkeydown, key);
        }
        mouseWheel(e) {
            GameEventManager.event(GameEventType.mouseWheel, e.delta);
        }
        isKeyDwon(key) {
            return this.keyDownMap.get(key);
        }
    }
    //# sourceMappingURL=MOUSEMGR.js.map

    /*! *****************************************************************************
    Copyright (c) Microsoft Corporation. All rights reserved.
    Licensed under the Apache License, Version 2.0 (the "License"); you may not use
    this file except in compliance with the License. You may obtain a copy of the
    License at http://www.apache.org/licenses/LICENSE-2.0

    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
    KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
    WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
    MERCHANTABLITY OR NON-INFRINGEMENT.

    See the Apache Version 2.0 License for specific language governing permissions
    and limitations under the License.
    ***************************************************************************** */
    /* global Reflect, Promise */

    var extendStatics = function(d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };

    function __extends(d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    }

    var __assign = function() {
        __assign = Object.assign || function __assign(t) {
            for (var s, i = 1, n = arguments.length; i < n; i++) {
                s = arguments[i];
                for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
            }
            return t;
        };
        return __assign.apply(this, arguments);
    };

    function __rest(s, e) {
        var t = {};
        for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
            t[p] = s[p];
        if (s != null && typeof Object.getOwnPropertySymbols === "function")
            for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
                if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                    t[p[i]] = s[p[i]];
            }
        return t;
    }

    function __decorate(decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    }

    function __param(paramIndex, decorator) {
        return function (target, key) { decorator(target, key, paramIndex); }
    }

    function __metadata(metadataKey, metadataValue) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(metadataKey, metadataValue);
    }

    function __awaiter(thisArg, _arguments, P, generator) {
        return new (P || (P = Promise))(function (resolve, reject) {
            function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
            function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
            function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
            step((generator = generator.apply(thisArg, _arguments || [])).next());
        });
    }

    function __generator(thisArg, body) {
        var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
        return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
        function verb(n) { return function (v) { return step([n, v]); }; }
        function step(op) {
            if (f) throw new TypeError("Generator is already executing.");
            while (_) try {
                if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
                if (y = 0, t) op = [op[0] & 2, t.value];
                switch (op[0]) {
                    case 0: case 1: t = op; break;
                    case 4: _.label++; return { value: op[1], done: false };
                    case 5: _.label++; y = op[1]; op = [0]; continue;
                    case 7: op = _.ops.pop(); _.trys.pop(); continue;
                    default:
                        if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                        if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                        if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                        if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                        if (t[2]) _.ops.pop();
                        _.trys.pop(); continue;
                }
                op = body.call(thisArg, _);
            } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
            if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
        }
    }

    function __exportStar(m, exports) {
        for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
    }

    function __values(o) {
        var m = typeof Symbol === "function" && o[Symbol.iterator], i = 0;
        if (m) return m.call(o);
        return {
            next: function () {
                if (o && i >= o.length) o = void 0;
                return { value: o && o[i++], done: !o };
            }
        };
    }

    function __read(o, n) {
        var m = typeof Symbol === "function" && o[Symbol.iterator];
        if (!m) return o;
        var i = m.call(o), r, ar = [], e;
        try {
            while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
        }
        catch (error) { e = { error: error }; }
        finally {
            try {
                if (r && !r.done && (m = i["return"])) m.call(i);
            }
            finally { if (e) throw e.error; }
        }
        return ar;
    }

    function __spread() {
        for (var ar = [], i = 0; i < arguments.length; i++)
            ar = ar.concat(__read(arguments[i]));
        return ar;
    }

    function __spreadArrays() {
        for (var s = 0, i = 0, il = arguments.length; i < il; i++) s += arguments[i].length;
        for (var r = Array(s), k = 0, i = 0; i < il; i++)
            for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++)
                r[k] = a[j];
        return r;
    };

    function __await(v) {
        return this instanceof __await ? (this.v = v, this) : new __await(v);
    }

    function __asyncGenerator(thisArg, _arguments, generator) {
        if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
        var g = generator.apply(thisArg, _arguments || []), i, q = [];
        return i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i;
        function verb(n) { if (g[n]) i[n] = function (v) { return new Promise(function (a, b) { q.push([n, v, a, b]) > 1 || resume(n, v); }); }; }
        function resume(n, v) { try { step(g[n](v)); } catch (e) { settle(q[0][3], e); } }
        function step(r) { r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r); }
        function fulfill(value) { resume("next", value); }
        function reject(value) { resume("throw", value); }
        function settle(f, v) { if (f(v), q.shift(), q.length) resume(q[0][0], q[0][1]); }
    }

    function __asyncDelegator(o) {
        var i, p;
        return i = {}, verb("next"), verb("throw", function (e) { throw e; }), verb("return"), i[Symbol.iterator] = function () { return this; }, i;
        function verb(n, f) { i[n] = o[n] ? function (v) { return (p = !p) ? { value: __await(o[n](v)), done: n === "return" } : f ? f(v) : v; } : f; }
    }

    function __asyncValues(o) {
        if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
        var m = o[Symbol.asyncIterator], i;
        return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i);
        function verb(n) { i[n] = o[n] && function (v) { return new Promise(function (resolve, reject) { v = o[n](v), settle(resolve, reject, v.done, v.value); }); }; }
        function settle(resolve, reject, d, v) { Promise.resolve(v).then(function(v) { resolve({ value: v, done: d }); }, reject); }
    }

    function __makeTemplateObject(cooked, raw) {
        if (Object.defineProperty) { Object.defineProperty(cooked, "raw", { value: raw }); } else { cooked.raw = raw; }
        return cooked;
    };

    function __importStar(mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
        result.default = mod;
        return result;
    }

    function __importDefault(mod) {
        return (mod && mod.__esModule) ? mod : { default: mod };
    }

    class MapMgr {
        constructor() {
            this.mapId = 0;
            this.mapwidth = 0;
            this.mapheight = 0;
            this.gridWH = 0;
            this.areaWH = 512; //固定尺寸，勿修改
            /** 区域信息 */
            this.areaMap = new Map();
            /** 可行走信息 */
            this.walks = [];
            /** 云信息 */
            this.cloudInfo = new Map();
            /** 继续编辑获取的点位信息 */
            this.pointGrids = [];
        }
        static get ins() { return MapMgr["_ins"] || (MapMgr["_ins"] = new MapMgr()); }
    }
    //# sourceMappingURL=MapMgr.js.map

    class ResConfig {
        static getMapImgUrl(mapId) {
            return ResConfig.resRoot + "map/2/MapBigImg/" + mapId + ".jpg";
        }
        static getJsonDataUrl(mapId) {
            return ResConfig.resRoot + "map/2/Json/MapData" + mapId + ".json";
        }
        static getJsonDataUrlPoint(mapId) {
            return ResConfig.resRoot + "map/2/Json/MapDataPoint" + mapId + ".json";
        }
        static cloudImgUrl() {
            return ResConfig.resRoot + "map/2/MapImg/cloud.png";
        }
    }
    ResConfig.resRoot = 'http://192.168.11.28:8888/other/zhuiyue2/resource/res/';
    ResConfig.defaultPieceUrl = ResConfig.resRoot + "map/1/Piece/default.png";
    //# sourceMappingURL=ResConfig.js.map

    class ResLoadMgr {
        static Load(url) {
            return new Promise((resolve) => {
                Laya.loader.load(url, Laya.Handler.create(this, (res) => {
                    resolve(res);
                }));
            });
        }
    }
    //# sourceMappingURL=ResLoadMgr.js.map

    /** This is an automatically generated class by FairyGUI. Please do not modify it. **/
    class UI_start extends fgui.GComponent {
        static createInstance() {
            return (fgui.UIPackage.createObject("Package1", "start"));
        }
        onConstruct() {
            this.m_btn_start = (this.getChildAt(2));
            this.m_mapId = (this.getChildAt(5));
            this.m_gridWH = (this.getChildAt(9));
            this.m_btn_continue = (this.getChildAt(12));
        }
    }
    UI_start.URL = "ui://1d2nl1i7qx2p0";
    //# sourceMappingURL=UI_start.js.map

    class MapUIMgr {
        constructor() {
            this.mapComScale = 1;
            /** 行走编辑 是否可行走 */
            this.walkEdit_isTrue = true;
            /** 点位的设置和取消 */
            this.pointEdit_isTrue = true;
            /** 当前选择区域 */
            this._curSeleArea = 1;
            /** grid */
            this.grids = [];
            this.pointGrids = [];
            this.cloudMap = new Map();
            this.areaDefaultColor = "#FFFFFF";
            this.areaColorMap = "#DC143C";
        }
        static get ins() { return MapUIMgr["_ins"] || (MapUIMgr["_ins"] = new MapUIMgr()); }
        set curSeleArea(value) {
            this._curSeleArea = value;
            GameEventManager.event(GameEventType.areaIndexChange);
        }
        get curSeleArea() {
            return this._curSeleArea;
        }
        set curSeleCloud(value) {
            if (this._curSeleCloud)
                this._curSeleCloud.sele = false;
            this._curSeleCloud = value;
            value.sele = true;
            this.cloudInfoCom.updataSele();
        }
        get curSeleCloud() {
            return this._curSeleCloud;
        }
    }
    //# sourceMappingURL=MapUIMgr.js.map

    /** This is an automatically generated class by FairyGUI. Please do not modify it. **/
    class UI_grid extends fgui.GButton {
        static createInstance() {
            return (fgui.UIPackage.createObject("Package1", "grid"));
        }
        onConstruct() {
            this.m_a = (this.getChildAt(0));
            this.m_point = (this.getChildAt(1));
        }
    }
    UI_grid.URL = "ui://1d2nl1i7d8vm7";
    //# sourceMappingURL=UI_grid.js.map

    class GridCom {
        constructor(px, py) {
            this.ui = UI_grid.createInstance();
            this.ui.setSize(MapMgr.ins.gridWH, MapMgr.ins.gridWH);
            this.ui.x = px * MapMgr.ins.gridWH;
            this.ui.y = py * MapMgr.ins.gridWH;
            this.px = px;
            this.py = py;
            this.c_button = this.ui.getController("button");
            this.c_button.on(fgui.Events.STATE_CHANGED, this, this.c_ButtonChange);
            this.ui.m_point.text = "(" + px + "," + py + ")";
            if (MapMgr.ins.walks.indexOf(px + "_" + py) != -1)
                this.ui.m_a.alpha = 0;
            GameEventManager.on(GameEventType.onkeydown, this, this.onkeydown);
            GameEventManager.on(GameEventType.onkeyup, this, this.onkeydown);
        }
        c_ButtonChange() {
            if ((MOUSEMGR.ins.isMouseDown && MOUSEMGR.ins.isKeyDwon(17) && this.c_button.selectedIndex == 2) || (this.c_button.selectedIndex == 1 && MOUSEMGR.ins.isKeyDwon(17))) {
                this.ui.m_a.alpha = MapUIMgr.ins.walkEdit_isTrue ? 0 : 0.2;
            }
        }
        onkeydown() {
            this.ui.m_point.visible = MOUSEMGR.ins.isKeyDwon(32);
        }
    }
    //# sourceMappingURL=GridCom.js.map

    class PointGridCom extends GridCom {
        constructor(px, py) {
            super(px, py);
            this.ui.m_a.alpha = 0.2;
            if (MapMgr.ins.pointGrids.indexOf(px + "_" + py) != -1)
                this.ui.m_a.color = PointGridCom.greencolor;
        }
        c_ButtonChange() {
            if ((MOUSEMGR.ins.isMouseDown && MOUSEMGR.ins.isKeyDwon(17) && this.c_button.selectedIndex == 2) || (this.c_button.selectedIndex == 1 && MOUSEMGR.ins.isKeyDwon(17))) {
                this.ui.m_a.color = MapUIMgr.ins.pointEdit_isTrue ? PointGridCom.greencolor : PointGridCom.redcolor;
            }
        }
    }
    //红色
    PointGridCom.redcolor = "#FF0000";
    //绿色
    PointGridCom.greencolor = "#008000";
    //# sourceMappingURL=PointGridCom.js.map

    class ExportData {
    }
    /** 导出数据 */
    function exportData() {
        let data = new ExportData();
        data.areaWH = MapMgr.ins.areaWH;
        data.gridWH = MapMgr.ins.gridWH;
        data.mapWidth = MapMgr.ins.mapwidth;
        data.mapHeight = MapMgr.ins.mapheight;
        data.areaInfo = [];
        data.walkPoint = [];
        data.cloudInfo = [];
        //获取所有可行走块
        MapUIMgr.ins.grids.forEach(grid => {
            if (grid.ui.m_a.alpha == 0)
                data.walkPoint.push(grid.px + "_" + grid.py);
        });
        MapUIMgr.ins.cloudMap.forEach((v, k) => {
            if (v.offX != 0 || v.offy != 0)
                data.cloudInfo.push({ cloudKey: k, offxy: { offx: v.offX, offy: v.offy } });
        });
        MapMgr.ins.areaMap.forEach((v, k) => {
            data.areaInfo.push({ areaIndex: k, area: v });
        });
        let fileName = "MapData" + MapMgr.ins.mapId + ".json";
        window['downloadFile'](JSON.stringify(data), fileName, "text/plain");
    }
    function exportPointData() {
        let data = [];
        //获取绿色点位导出
        MapUIMgr.ins.pointGrids.forEach(grid => {
            if (grid.ui.m_a.color == PointGridCom.greencolor)
                data.push({ x: grid.px, y: grid.py });
        });
        let str = "";
        data.forEach(info => {
            let index = data.indexOf(info);
            if (index != data.length - 1)
                str += info.x + "#" + info.y + ",";
            else
                str += info.x + "#" + info.y;
        });
        let fileName = "MapDataPoint" + MapMgr.ins.mapId + ".txt";
        window['downloadFile'](str, fileName, "text/plain");
    }
    //# sourceMappingURL=ExportData.js.map

    /** This is an automatically generated class by FairyGUI. Please do not modify it. **/
    class UI_MainPanel extends fgui.GComponent {
        static createInstance() {
            return (fgui.UIPackage.createObject("Package1", "MainPanel"));
        }
        onConstruct() {
            this.m_c_func = this.getControllerAt(0);
            this.m_cloudInfo = (this.getChildAt(5));
            this.m_ls_area = (this.getChildAt(6));
            this.m_ls_walkEditTF = (this.getChildAt(7));
            this.m_ls_pointEditTF = (this.getChildAt(8));
            this.m_map = (this.getChildAt(9));
            this.m_export = (this.getChildAt(10));
            this.m_exportPoint = (this.getChildAt(11));
            this.m_building = (this.getChildAt(14));
        }
    }
    UI_MainPanel.URL = "ui://1d2nl1i7d8vm3";
    //# sourceMappingURL=UI_MainPanel.js.map

    class CloudInfoCom {
        constructor(ui) {
            this.ui = ui;
            GameEventManager.on(GameEventType.onkeydown, this, this.onkeydown);
        }
        updataSele() {
            this.ui.m_px.text = MapUIMgr.ins.curSeleCloud.px + "";
            this.ui.m_py.text = MapUIMgr.ins.curSeleCloud.py + "";
            this.ui.m_x.text = MapUIMgr.ins.curSeleCloud.offX + "";
            this.ui.m_y.text = MapUIMgr.ins.curSeleCloud.offy + "";
        }
        onkeydown(key) {
            if (!this.ui.visible)
                return;
            if (!MapUIMgr.ins.curSeleCloud)
                return;
            //上下左右
            switch (key) {
                case 38:
                    MapUIMgr.ins.curSeleCloud.updateOff(0, -1);
                    break;
                case 40:
                    MapUIMgr.ins.curSeleCloud.updateOff(0, 1);
                    break;
                case 37:
                    MapUIMgr.ins.curSeleCloud.updateOff(-1, 0);
                    break;
                case 39:
                    MapUIMgr.ins.curSeleCloud.updateOff(1, 0);
                    break;
            }
            this.updataSele();
        }
    }
    //# sourceMappingURL=CloudInfoCom.js.map

    const sleep = (delay) => new Promise((resolve) => setTimeout(resolve, delay));
    const sleep_frame = (frame) => new Promise((resolve) => Laya.timer.frameOnce(frame, null, resolve));
    //# sourceMappingURL=WaitDelay.js.map

    /** This is an automatically generated class by FairyGUI. Please do not modify it. **/
    class UI_area extends fgui.GButton {
        static createInstance() {
            return (fgui.UIPackage.createObject("Package1", "area"));
        }
        onConstruct() {
            this.m_a = (this.getChildAt(0));
        }
    }
    UI_area.URL = "ui://1d2nl1i7d8vm9";
    //# sourceMappingURL=UI_area.js.map

    class AreaCom {
        constructor(px, py) {
            this.ui = UI_area.createInstance();
            this.ui.x = px * MapMgr.ins.areaWH;
            this.ui.y = py * MapMgr.ins.areaWH;
            this.ui.onClick(this, this.setArea);
            //s_id命名：由mapId+"_"+index组成 index由1自增
            this.s_id = MapMgr.ins.mapId + "_" + AreaCom.index;
            AreaCom.index++;
            GameEventManager.on(GameEventType.areaIndexChange, this, this.update);
        }
        setArea() {
            let curAreas = MapMgr.ins.areaMap.get(MapUIMgr.ins.curSeleArea) || [];
            if (curAreas.indexOf(this.s_id) != -1) {
                curAreas = curAreas.filter(v => v != this.s_id);
            }
            else {
                curAreas.push(this.s_id);
            }
            MapMgr.ins.areaMap.set(MapUIMgr.ins.curSeleArea, curAreas);
            this.update();
        }
        update() {
            let curAreas = MapMgr.ins.areaMap.get(MapUIMgr.ins.curSeleArea) || [];
            if (curAreas.indexOf(this.s_id) != -1) {
                this.ui.m_a.color = MapUIMgr.ins.areaColorMap;
            }
            else {
                this.ui.m_a.color = MapUIMgr.ins.areaDefaultColor;
            }
        }
    }
    AreaCom.index = 1;
    //# sourceMappingURL=AreaCom.js.map

    /** This is an automatically generated class by FairyGUI. Please do not modify it. **/
    class UI_cloud extends fgui.GComponent {
        static createInstance() {
            return (fgui.UIPackage.createObject("Package1", "cloud"));
        }
        onConstruct() {
            this.m_c_sele = this.getControllerAt(0);
            this.m_icon = (this.getChildAt(0));
        }
    }
    UI_cloud.URL = "ui://1d2nl1i7ayjbg";
    //# sourceMappingURL=UI_cloud.js.map

    class CloudCom {
        constructor(px, py) {
            this.offX = 0;
            this.offy = 0;
            this.ui = UI_cloud.createInstance();
            this.ui.x = px * MapMgr.ins.areaWH;
            this.ui.y = py * MapMgr.ins.areaWH;
            this.px = px;
            this.py = py;
            this.x = this.ui.x;
            this.y = this.ui.y;
            this.ui.m_icon.url = ResConfig.cloudImgUrl();
            //s_id命名：由mapId+"_"+index组成 index由1自增
            this.s_id = MapMgr.ins.mapId + "_" + CloudCom.index;
            MapUIMgr.ins.cloudMap.set(this.s_id, this);
            CloudCom.index++;
            if (MapMgr.ins.cloudInfo.get(this.s_id)) {
                let offX = MapMgr.ins.cloudInfo.get(this.s_id).offX;
                let offy = MapMgr.ins.cloudInfo.get(this.s_id).offy;
                this.updateOff(offX, offy);
            }
            this.ui.onClick(this, this.clickThis);
        }
        set sele(value) {
            this.ui.m_c_sele.selectedIndex = value ? 1 : 0;
        }
        clickThis() {
            MapUIMgr.ins.curSeleCloud = this;
        }
        updateOff(offx, offy) {
            this.offX += offx;
            this.offy += offy;
            this.ui.x = this.x + this.offX;
            this.ui.y = this.y + this.offy;
        }
    }
    CloudCom.index = 1;

    class MapCom {
        constructor(ui) {
            this.ui = ui;
            this.ui.scrollPane.mouseWheelEnabled = false;
            this.ui.m_wh.width = MapMgr.ins.mapwidth;
            this.ui.m_wh.height = MapMgr.ins.mapheight;
            GameEventManager.on(GameEventType.mouseWheel, this, this.onMouseWheel);
            GameEventManager.on(GameEventType.onkeydown, this, this.onKey);
            GameEventManager.on(GameEventType.onkeyup, this, this.onKey);
        }
        init() {
            return __awaiter(this, void 0, void 0, function* () {
                yield this.initGrid();
                yield this.initArea();
                yield this.initGridPoint();
                yield this.initCloud();
            });
        }
        /** 初始化网格 */
        initGrid() {
            return __awaiter(this, void 0, void 0, function* () {
                let gridWH = MapMgr.ins.gridWH;
                let mapwidth = MapMgr.ins.mapwidth;
                let mapheight = MapMgr.ins.mapheight;
                let row = Math.ceil(mapheight / gridWH);
                let col = Math.ceil(mapwidth / gridWH);
                let index = 0;
                for (let i = 0; i < row; i++) {
                    for (let j = 0; j < col; j++) {
                        let grid = new GridCom(j, i);
                        this.ui.m_gridLayer.addChild(grid.ui);
                        MapUIMgr.ins.grids.push(grid);
                        index++;
                        if (index % 400 == 0)
                            yield sleep_frame(1);
                    }
                }
            });
        }
        /** 初始化网格点位 */
        initGridPoint() {
            return __awaiter(this, void 0, void 0, function* () {
                let gridWH = MapMgr.ins.gridWH;
                let mapwidth = MapMgr.ins.mapwidth;
                let mapheight = MapMgr.ins.mapheight;
                let row = Math.ceil(mapheight / gridWH);
                let col = Math.ceil(mapwidth / gridWH);
                let index = 0;
                for (let i = 0; i < row; i++) {
                    for (let j = 0; j < col; j++) {
                        let grid = new PointGridCom(j, i);
                        this.ui.m_pointLayer.addChild(grid.ui);
                        MapUIMgr.ins.pointGrids.push(grid);
                        index++;
                        if (index % 400 == 0)
                            yield sleep_frame(1);
                    }
                }
            });
        }
        /** 初始化区域编辑 */
        initArea() {
            return __awaiter(this, void 0, void 0, function* () {
                let areaWH = MapMgr.ins.areaWH;
                let mapwidth = MapMgr.ins.mapwidth;
                let mapheight = MapMgr.ins.mapheight;
                let row = Math.ceil(mapheight / areaWH);
                let col = Math.ceil(mapwidth / areaWH);
                let index = 0;
                for (let i = 0; i < row; i++) {
                    for (let j = 0; j < col; j++) {
                        let area = new AreaCom(j, i);
                        this.ui.m_areaLayer.addChild(area.ui);
                        index++;
                        if (index % 400 == 0)
                            yield sleep_frame(1);
                    }
                }
            });
        }
        /** 初始化云 */
        initCloud() {
            return __awaiter(this, void 0, void 0, function* () {
                let areaWH = MapMgr.ins.areaWH;
                let mapwidth = MapMgr.ins.mapwidth;
                let mapheight = MapMgr.ins.mapheight;
                let row = Math.ceil(mapheight / areaWH);
                let col = Math.ceil(mapwidth / areaWH);
                let index = 0;
                for (let i = 0; i < row; i++) {
                    for (let j = 0; j < col; j++) {
                        let area = new CloudCom(j, i);
                        this.ui.m_cloudLayer.addChild(area.ui);
                        index++;
                        if (index % 400 == 0)
                            yield sleep_frame(1);
                    }
                }
            });
        }
        onMouseWheel(delta) {
            if (!MOUSEMGR.ins.isKeyDwon(17))
                return;
            MapUIMgr.ins.mapComScale += delta > 0 ? 0.01 : -0.01;
            MapUIMgr.ins.mapComScale = Math.max(0.1, Math.min(2, MapUIMgr.ins.mapComScale));
            this.setScale(MapUIMgr.ins.mapComScale);
        }
        setScale(scale) {
            let W = MapMgr.ins.mapwidth * scale;
            let H = MapMgr.ins.mapheight * scale;
            this.ui.m_wh.width = W;
            this.ui.m_wh.height = H;
            this.ui.m_mapImg.setScale(scale, scale);
            this.ui.m_gridLayer.setScale(scale, scale);
            this.ui.m_areaLayer.setScale(scale, scale);
        }
        onKey() {
            if (!MOUSEMGR.ins.isKeyDwon(17)) {
                this.ui.scrollPane.touchEffect = true;
            }
            else {
                this.ui.scrollPane.touchEffect = false;
            }
        }
    }
    //# sourceMappingURL=MapCom.js.map

    class MainPanel {
        constructor() {
            this.ui = UI_MainPanel.createInstance();
            this.ui.makeFullScreen();
            fgui.GRoot.inst.addChild(this.ui);
            this.ui.m_map.m_mapImg.url = ResConfig.getMapImgUrl(MapMgr.ins.mapId);
            this.ui.m_ls_walkEditTF.onClick(this, this.onClickWalkTF);
            this.ui.m_ls_pointEditTF.onClick(this, this.onClickPointTF);
            this.ui.m_ls_pointEditTF.selectedIndex = 0;
            this.ui.m_ls_walkEditTF.selectedIndex = 0;
            this.ui.m_ls_area.onClick(this, this.onclickArea);
            this.ui.m_ls_area.selectedIndex = 0;
            this.ui.m_c_func.on(fgui.Events.STATE_CHANGED, this, this.onFuncChange);
            this.ui.m_export.onClick(this, this.onExport);
            this.ui.m_exportPoint.onClick(this, this.onExportPoint);
            this.initMap();
        }
        initMap() {
            return __awaiter(this, void 0, void 0, function* () {
                MapUIMgr.ins.mapCom = new MapCom(this.ui.m_map);
                MapUIMgr.ins.cloudInfoCom = new CloudInfoCom(this.ui.m_cloudInfo);
                yield MapUIMgr.ins.mapCom.init();
                this.ui.m_building.visible = false;
                GameEventManager.event(GameEventType.areaIndexChange);
            });
        }
        onFuncChange() {
            let index = this.ui.m_c_func.selectedIndex;
            [
                this.ui.m_map.m_gridLayer,
                this.ui.m_map.m_areaLayer,
                this.ui.m_map.m_pointLayer,
                this.ui.m_map.m_cloudLayer,
            ].forEach(ui => ui.visible = false);
            switch (index) {
                case FuncType._划分区域_:
                    this.ui.m_map.m_areaLayer.visible = true;
                    break;
                case FuncType._编辑行走区域_:
                    this.ui.m_map.m_gridLayer.visible = true;
                    break;
                case FuncType._点位信息_:
                    this.ui.m_map.m_pointLayer.visible = true;
                    break;
                case FuncType._云信息_:
                    this.ui.m_map.m_cloudLayer.visible = true;
                    break;
                default:
                    break;
            }
        }
        onClickWalkTF() {
            let isTrue = this.ui.m_ls_walkEditTF.selectedIndex == 0;
            MapUIMgr.ins.walkEdit_isTrue = isTrue;
        }
        onClickPointTF() {
            let isTrue = this.ui.m_ls_pointEditTF.selectedIndex == 0;
            MapUIMgr.ins.pointEdit_isTrue = isTrue;
        }
        onclickArea() {
            MapUIMgr.ins.curSeleArea = this.ui.m_ls_area.selectedIndex + 1;
        }
        onExport() {
            exportData();
        }
        onExportPoint() {
            exportPointData();
        }
    }
    var FuncType;
    (function (FuncType) {
        FuncType[FuncType["_null_"] = 0] = "_null_";
        FuncType[FuncType["_\u5212\u5206\u533A\u57DF_"] = 1] = "_\u5212\u5206\u533A\u57DF_";
        FuncType[FuncType["_\u7F16\u8F91\u884C\u8D70\u533A\u57DF_"] = 2] = "_\u7F16\u8F91\u884C\u8D70\u533A\u57DF_";
        FuncType[FuncType["_\u70B9\u4F4D\u4FE1\u606F_"] = 3] = "_\u70B9\u4F4D\u4FE1\u606F_";
        FuncType[FuncType["_\u4E91\u4FE1\u606F_"] = 4] = "_\u4E91\u4FE1\u606F_";
    })(FuncType || (FuncType = {}));
    //# sourceMappingURL=MainPanel.js.map

    class StartPanel {
        constructor() {
            this.ui = UI_start.createInstance();
            this.ui.makeFullScreen();
            fgui.GRoot.inst.addChild(this.ui);
            this.ui.m_btn_start.onClick(this, this.onStartClick);
            this.ui.m_mapId.text = "1";
            this.ui.m_gridWH.text = "100";
        }
        onStartClick() {
            return __awaiter(this, void 0, void 0, function* () {
                let mapId = this.ui.m_mapId.text;
                let gridWH = this.ui.m_gridWH.text;
                //检测是否是数字
                if (isNaN(Number(mapId)) || isNaN(Number(gridWH))) {
                    console.log("mapId is not a number");
                    return;
                }
                if (Number(gridWH) <= 0) {
                    console.log("gridWH is not a number");
                }
                let isContinue = this.ui.m_btn_continue.selected;
                if (isContinue) {
                    let data = yield ResLoadMgr.Load(ResConfig.getJsonDataUrl(Number(mapId)));
                    if (data) {
                        let gwh = data.gridWH;
                        if (gridWH != gwh.toString()) {
                            console.log("网格大小不匹配，以使用历史网格大小");
                            gridWH = gwh.toString();
                        }
                        MapMgr.ins.areaMap = new Map();
                        data.areaInfo.forEach(info => {
                            MapMgr.ins.areaMap.set(info.areaIndex, info.area);
                        });
                        MapMgr.ins.walks = data.walkPoint;
                        let cloudInfo = data.cloudInfo;
                        if (cloudInfo) {
                            cloudInfo.forEach(v => {
                                MapMgr.ins.cloudInfo.set(v.cloudKey, { offX: v.offxy.offx, offy: v.offxy.offy });
                            });
                        }
                    }
                    else {
                        console.log("没有对应数据信息，重新构建");
                    }
                    let data1 = yield ResLoadMgr.Load(ResConfig.getJsonDataUrlPoint(Number(mapId)));
                    if (data1) {
                        data1.forEach(info => {
                            MapMgr.ins.pointGrids.push(info.x + "_" + info.y);
                        });
                    }
                }
                let res = yield ResLoadMgr.Load(ResConfig.getMapImgUrl(Number(mapId)));
                if (res) {
                    this.ui.dispose();
                    MapMgr.ins.mapId = Number(mapId);
                    MapMgr.ins.mapwidth = res.width;
                    MapMgr.ins.mapheight = res.height;
                    MapMgr.ins.gridWH = Number(gridWH);
                    new MainPanel();
                }
                else {
                    console.log("mapId is not exist");
                }
                console.log("start game");
            });
        }
    }
    //# sourceMappingURL=StartPanel.js.map

    /** This is an automatically generated class by FairyGUI. Please do not modify it. **/
    class UI_cloudInfo extends fgui.GComponent {
        static createInstance() {
            return (fgui.UIPackage.createObject("Package1", "cloudInfo"));
        }
        onConstruct() {
            this.m_px = (this.getChildAt(2));
            this.m_py = (this.getChildAt(6));
            this.m_x = (this.getChildAt(10));
            this.m_y = (this.getChildAt(14));
        }
    }
    UI_cloudInfo.URL = "ui://1d2nl1i7ayjbf";
    //# sourceMappingURL=UI_cloudInfo.js.map

    /** This is an automatically generated class by FairyGUI. Please do not modify it. **/
    class UI_MapCom extends fgui.GComponent {
        static createInstance() {
            return (fgui.UIPackage.createObject("Package1", "MapCom"));
        }
        onConstruct() {
            this.m_button = this.getControllerAt(0);
            this.m_wh = (this.getChildAt(0));
            this.m_mapImg = (this.getChildAt(1));
            this.m_gridLayer = (this.getChildAt(2));
            this.m_areaLayer = (this.getChildAt(3));
            this.m_pointLayer = (this.getChildAt(4));
            this.m_cloudLayer = (this.getChildAt(5));
        }
    }
    UI_MapCom.URL = "ui://1d2nl1i7d8vm5";
    //# sourceMappingURL=UI_MapCom.js.map

    /** This is an automatically generated class by FairyGUI. Please do not modify it. **/
    class Package1Binder {
        static bindAll() {
            fgui.UIObjectFactory.setExtension(UI_cloudInfo.URL, UI_cloudInfo);
            fgui.UIObjectFactory.setExtension(UI_cloud.URL, UI_cloud);
            fgui.UIObjectFactory.setExtension(UI_MainPanel.URL, UI_MainPanel);
            fgui.UIObjectFactory.setExtension(UI_MapCom.URL, UI_MapCom);
            fgui.UIObjectFactory.setExtension(UI_grid.URL, UI_grid);
            fgui.UIObjectFactory.setExtension(UI_area.URL, UI_area);
            fgui.UIObjectFactory.setExtension(UI_start.URL, UI_start);
        }
    }
    //# sourceMappingURL=Package1Binder.js.map

    class Main {
        constructor() {
            Config.useRetinalCanvas = true;
            //根据IDE设置初始化引擎		
            if (window["Laya3D"])
                Laya3D.init(GameConfig.width, GameConfig.height);
            else
                Laya.init(GameConfig.width, GameConfig.height, Laya["WebGL"]);
            Laya["Physics"] && Laya["Physics"].enable();
            Laya["DebugPanel"] && Laya["DebugPanel"].enable();
            Laya.stage.scaleMode = GameConfig.scaleMode;
            Laya.stage.screenMode = GameConfig.screenMode;
            Laya.stage.alignV = GameConfig.alignV;
            Laya.stage.alignH = GameConfig.alignH;
            Laya.stage.bgColor = "#efeed7";
            //兼容微信不支持加载scene后缀场景
            Laya.URL.exportSceneToJson = GameConfig.exportSceneToJson;
            //打开调试面板（通过IDE设置调试模式，或者url地址增加debug=true参数，均可打开调试面板）
            if (GameConfig.debug || Laya.Utils.getQueryString("debug") == "true")
                Laya.enableDebugPanel();
            if (GameConfig.physicsDebug && Laya["PhysicsDebugDraw"])
                Laya["PhysicsDebugDraw"].enable();
            if (GameConfig.stat)
                Laya.Stat.show();
            Laya.alertGlobalError(true);
            //激活资源版本控制，version.json由IDE发布功能自动生成，如果没有也不影响后续流程
            Laya.ResourceVersion.enable("version.json", Laya.Handler.create(this, this.onVersionLoaded), Laya.ResourceVersion.FILENAME_VERSION);
        }
        onVersionLoaded() {
            //激活大小图映射，加载小图的时候，如果发现小图在大图合集里面，则优先加载大图合集，而不是小图
            Laya.AtlasInfoManager.enable("fileconfig.json", Laya.Handler.create(this, this.onConfigLoaded));
        }
        onConfigLoaded() {
            Laya.stage.addChild(fgui.GRoot.inst.displayObject);
            let res = [];
            res.push({ url: "res/fgui/Package1.fui", type: 'arraybuffer' });
            res.push({ url: "res/fgui/Package1_atlas0.jpg" });
            //加载fguipackage
            Laya.loader.load(res, Laya.Handler.create(this, (res) => {
                fgui.UIPackage.addPackage("res/fgui/Package1");
                new StartPanel();
            }));
        }
    }
    //激活启动类
    new Main();
    Package1Binder.bindAll();
    MOUSEMGR.ins;
    //# sourceMappingURL=Main.js.map

}());
//# sourceMappingURL=bundle.js.map
