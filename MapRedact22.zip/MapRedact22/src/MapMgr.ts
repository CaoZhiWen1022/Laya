export class MapMgr {

    static get ins(): MapMgr { return MapMgr["_ins"] || (MapMgr["_ins"] = new MapMgr()); }

    mapId: number = 0;
    mapwidth: number = 0;
    mapheight: number = 0;
    gridWH: number = 0;
    readonly areaWH: number = 512;//固定尺寸，勿修改

    /** 区域信息 */
    areaMap: Map<number, string[]> = new Map();

    /** 可行走信息 */
    walks: string[] = [];

    /** 云信息 */
    cloudInfo: Map<string, { offX: number, offy: number }> = new Map()

    /** 继续编辑获取的点位信息 */
    pointGrids: string[] = []


}