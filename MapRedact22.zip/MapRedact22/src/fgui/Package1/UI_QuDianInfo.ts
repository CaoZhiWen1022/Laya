/** This is an automatically generated class by FairyGUI. Please do not modify it. **/

export default class UI_QuDianInfo extends fgui.GComponent {

	public m_info:fgui.GTextField;
	public m_del:fgui.GButton;
	public static URL:string = "ui://1d2nl1i7h88fi";

	public static createInstance():UI_QuDianInfo {
		return <UI_QuDianInfo>(fgui.UIPackage.createObject("Package1", "QuDianInfo"));
	}

	protected onConstruct():void {
		this.m_info = <fgui.GTextField>(this.getChildAt(1));
		this.m_del = <fgui.GButton>(this.getChildAt(2));
	}
}