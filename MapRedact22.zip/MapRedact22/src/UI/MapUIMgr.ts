import { GameEventManager, GameEventType } from "../GameEventManager";
import { CloudCom } from "./CloudCom";
import { CloudInfoCom } from "./CloudInfoCom";
import { GridCom } from "./GridCom";
import { MapCom } from "./MapCom";
import { PointGridCom } from "./PointGridCom";
import { QuDianGrid } from "./QuDianGrid";
import { UI_PointComExt } from "./UI_PointComExt";



export class MapUIMgr {
    static get ins(): MapUIMgr { return MapUIMgr["_ins"] || (MapUIMgr["_ins"] = new MapUIMgr()); }

    mapCom: MapCom;

    mapComScale = 1;

    /** 行走编辑 是否可行走 */
    walkEdit_isTrue = true;

    /** 点位的设置和取消 */
    pointEdit_isTrue = true;

    /** 当前选择区域 */
    _curSeleArea: number = 1;

    /** grid */
    grids: GridCom[] = [];

    pointGrids: PointGridCom[] = [];

    quDianGrids: QuDianGrid[] = [];
    quDianUiComS: UI_PointComExt[] = [];
    quDianUIIndex: number = 1;

    set curSeleArea(value: number) {
        this._curSeleArea = value;
        GameEventManager.event(GameEventType.areaIndexChange);
    }

    get curSeleArea() {
        return this._curSeleArea;
    }


    cloudInfoCom: CloudInfoCom;
    cloudMap: Map<string, CloudCom> = new Map();
    private _curSeleCloud: CloudCom;

    set curSeleCloud(value: CloudCom) {
        if (this._curSeleCloud) this._curSeleCloud.sele = false
        this._curSeleCloud = value;
        value.sele = true
        this.cloudInfoCom.updataSele();
    }

    get curSeleCloud() {
        return this._curSeleCloud;
    }
    areaDefaultColor = "#FFFFFF";
    areaColorMap = "#DC143C"
}