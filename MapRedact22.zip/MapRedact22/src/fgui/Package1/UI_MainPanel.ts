/** This is an automatically generated class by FairyGUI. Please do not modify it. **/

import UI_cloudInfo from "./UI_cloudInfo";
import UI_MapCom from "./UI_MapCom";

export default class UI_MainPanel extends fgui.GComponent {

	public m_c_func:fgui.Controller;
	public m_cloudInfo:UI_cloudInfo;
	public m_ls_area:fgui.GList;
	public m_ls_walkEditTF:fgui.GList;
	public m_ls_pointEditTF:fgui.GList;
	public m_map:UI_MapCom;
	public m_export:fgui.GButton;
	public m_exportPoint:fgui.GButton;
	public m_exportPoint_2:fgui.GButton;
	public m_building:fgui.GGroup;
	public m_quDianInput:fgui.GTextInput;
	public m_createQuDian:fgui.GButton;
	public static URL:string = "ui://1d2nl1i7d8vm3";

	public static createInstance():UI_MainPanel {
		return <UI_MainPanel>(fgui.UIPackage.createObject("Package1", "MainPanel"));
	}

	protected onConstruct():void {
		this.m_c_func = this.getControllerAt(0);
		this.m_cloudInfo = <UI_cloudInfo>(this.getChildAt(6));
		this.m_ls_area = <fgui.GList>(this.getChildAt(7));
		this.m_ls_walkEditTF = <fgui.GList>(this.getChildAt(8));
		this.m_ls_pointEditTF = <fgui.GList>(this.getChildAt(9));
		this.m_map = <UI_MapCom>(this.getChildAt(10));
		this.m_export = <fgui.GButton>(this.getChildAt(11));
		this.m_exportPoint = <fgui.GButton>(this.getChildAt(12));
		this.m_exportPoint_2 = <fgui.GButton>(this.getChildAt(13));
		this.m_building = <fgui.GGroup>(this.getChildAt(16));
		this.m_quDianInput = <fgui.GTextInput>(this.getChildAt(18));
		this.m_createQuDian = <fgui.GButton>(this.getChildAt(19));
	}
}