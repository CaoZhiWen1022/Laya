import { GameEventManager, GameEventType } from "../GameEventManager";
import { MOUSEMGR } from "../MOUSEMGR";
import { MapMgr } from "../MapMgr";
import UI_grid from "../fgui/Package1/UI_grid";
import { GridCom } from "./GridCom";
import { MapUIMgr } from "./MapUIMgr";

export class PointGridCom extends GridCom {

    //红色
    static redcolor = "#FF0000"
    //绿色
    static greencolor = "#008000"

    constructor(px, py) {
        super(px, py);
        this.ui.m_a.alpha = 0.2;
        if (MapMgr.ins.pointGrids.indexOf(px + "_" + py) != -1) this.ui.m_a.color = PointGridCom.greencolor;
    }

    c_ButtonChange() {
        if ((MOUSEMGR.ins.isMouseDown && MOUSEMGR.ins.isKeyDwon(17) && this.c_button.selectedIndex == 2) || (this.c_button.selectedIndex == 1 && MOUSEMGR.ins.isKeyDwon(17))) {
            this.ui.m_a.color = MapUIMgr.ins.pointEdit_isTrue ? PointGridCom.greencolor : PointGridCom.redcolor;
        }
    }
}