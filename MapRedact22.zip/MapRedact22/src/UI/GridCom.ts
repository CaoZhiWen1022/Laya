import { GameEventManager, GameEventType } from "../GameEventManager";
import { MOUSEMGR } from "../MOUSEMGR";
import { MapMgr } from "../MapMgr";
import UI_grid from "../fgui/Package1/UI_grid";
import { MapUIMgr } from "./MapUIMgr";

export class GridCom {
    ui: UI_grid;
    c_button: fgui.Controller;
    px: number;
    py: number;
    constructor(px: number, py: number) {
        this.ui = UI_grid.createInstance();
        this.ui.setSize(MapMgr.ins.gridWH, MapMgr.ins.gridWH);
        this.ui.x = px * MapMgr.ins.gridWH;
        this.ui.y = py * MapMgr.ins.gridWH;
        this.px = px;
        this.py = py;

        this.c_button = this.ui.getController("button")
        this.c_button.on(fgui.Events.STATE_CHANGED, this, this.c_ButtonChange)
        this.ui.m_point.text = "(" + px + "," + py + ")"
        if (MapMgr.ins.walks.indexOf(px + "_" + py) != -1) this.ui.m_a.alpha = 0;

        GameEventManager.on(GameEventType.onkeydown, this, this.onkeydown)
        GameEventManager.on(GameEventType.onkeyup, this, this.onkeydown)
    }

    c_ButtonChange() {
        if ((MOUSEMGR.ins.isMouseDown && MOUSEMGR.ins.isKeyDwon(17) && this.c_button.selectedIndex == 2) || (this.c_button.selectedIndex == 1 && MOUSEMGR.ins.isKeyDwon(17))) {
            this.ui.m_a.alpha = MapUIMgr.ins.walkEdit_isTrue ? 0 : 0.2;
        }
    }     

    onkeydown() {
        this.ui.m_point.visible = MOUSEMGR.ins.isKeyDwon(32)
    }

    // setWalk() {
    //     this.ui.m_a.alpha = MapUIMgr.ins.walkEdit_isTrue ? 0 : 0.2;
    // }
}