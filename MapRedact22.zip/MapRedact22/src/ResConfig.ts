export class ResConfig {

    static resRoot = 'http://192.168.11.28:8888/other/zhuiyue2/resource/res/'

    static defaultPieceUrl = ResConfig.resRoot + "map/1/Piece/default.png"

    static getMapImgUrl(mapId: number) {
        return ResConfig.resRoot + "map/2/MapBigImg/" + mapId + ".jpg"
    }

    static getJsonDataUrl(mapId: number) {
        return ResConfig.resRoot + "map/2/Json/MapData" + mapId + ".json"
    }

    static getJsonDataUrlPoint(mapId: number) {
        return ResConfig.resRoot + "map/2/Json/MapDataPoint" + mapId + ".json"
    }

    static cloudImgUrl() {
        return ResConfig.resRoot + "map/2/MapImg/cloud.png";
    }
}