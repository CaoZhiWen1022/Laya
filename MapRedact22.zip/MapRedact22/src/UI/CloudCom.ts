import { GameEventManager, GameEventType } from "../GameEventManager";
import { MapMgr } from "../MapMgr";
import { ResConfig } from "../ResConfig";
import UI_area from "../fgui/Package1/UI_area";
import UI_cloud from "../fgui/Package1/UI_cloud";
import { MapUIMgr } from "./MapUIMgr";

export class CloudCom {

    static index = 1;

    ui: UI_cloud;

    s_id: string;

    px: number;
    py: number;
    x: number;
    y: number;

    offX = 0;
    offy = 0;
    constructor(px: number, py: number) {
        this.ui = UI_cloud.createInstance();
        this.ui.x = px * MapMgr.ins.areaWH;
        this.ui.y = py * MapMgr.ins.areaWH;
        this.px = px;
        this.py = py;
        this.x = this.ui.x;
        this.y = this.ui.y;
        this.ui.m_icon.url = ResConfig.cloudImgUrl()

        //s_id命名：由mapId+"_"+index组成 index由1自增
        this.s_id = MapMgr.ins.mapId + "_" + CloudCom.index;
        MapUIMgr.ins.cloudMap.set(this.s_id, this);
        CloudCom.index++;

        if (MapMgr.ins.cloudInfo.get(this.s_id)) {
            let offX = MapMgr.ins.cloudInfo.get(this.s_id).offX;
            let offy = MapMgr.ins.cloudInfo.get(this.s_id).offy;
            this.updateOff(offX, offy);
        }

        this.ui.onClick(this, this.clickThis)
    }

    set sele(value: boolean) {
        this.ui.m_c_sele.selectedIndex = value ? 1 : 0
    }

    clickThis() {
        MapUIMgr.ins.curSeleCloud = this;
    }

    updateOff(offx: number, offy: number) {
        this.offX += offx;
        this.offy += offy;
        this.ui.x = this.x + this.offX;
        this.ui.y = this.y + this.offy;
    }

}