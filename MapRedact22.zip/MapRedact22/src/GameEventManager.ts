

export class GameEventManager {
	private static _Event = new Laya.EventDispatcher();

	public static onMsg(MsgType: number | string, caller: any, listener: Function, args: any[] = null) {
		var type = "messages.API" + MsgType;
		return GameEventManager.on(type, caller, listener, args);
	}

	public static on(type: string, caller: any, listener: Function, args: any[] = null) {
		return GameEventManager._Event.on(type, caller, listener, args);
	}

	public static once(type: string, caller: any, listener: Function, args: any[] = null) {
		return GameEventManager._Event.once(type, caller, listener, args);
	}

	public static offMsg(MsgType: any, caller: any, listener: Function, onceOnly: boolean = false) {
		var type = "messages.API" + MsgType;
		return GameEventManager.off(type, caller, listener, onceOnly);
	}

	public static off(type: string, caller: any, listener: Function, onceOnly: boolean = false) {
		return GameEventManager._Event.off(type, caller, listener, onceOnly);
	}

	public static eventMsg(MsgType: number | string, data: any = null): boolean {
		var type = "messages.API" + MsgType;
		return GameEventManager.event(type, data);
	}

	public static event(type: string, data: Array<any> | any = null): boolean {
		return GameEventManager._Event.event(type, data);
	}

	public static offAllCaller(caller: any) {
		return GameEventManager._Event.offAllCaller(caller);
	}

}
export let Dispatch = GameEventManager;

export enum GameEventType {
	ExploreMapContainerScroll = "ExploreMapContainerScroll",
	onkeydown = "onkeydown",
	onkeyup = "onkeyup",
	mouseWheel = "mouseWheel",

	areaIndexChange = "areaIndexChange"
}