export class ResLoadMgr {

    static Load(url: string) {
        return new Promise<any>((resolve) => {
            Laya.loader.load(url, Laya.Handler.create(this, (res) => {
                resolve(res)
            }))
        })
    }

}