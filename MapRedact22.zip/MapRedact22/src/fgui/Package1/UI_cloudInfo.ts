/** This is an automatically generated class by FairyGUI. Please do not modify it. **/

export default class UI_cloudInfo extends fgui.GComponent {

	public m_px:fgui.GTextField;
	public m_py:fgui.GTextField;
	public m_x:fgui.GTextInput;
	public m_y:fgui.GTextInput;
	public static URL:string = "ui://1d2nl1i7ayjbf";

	public static createInstance():UI_cloudInfo {
		return <UI_cloudInfo>(fgui.UIPackage.createObject("Package1", "cloudInfo"));
	}

	protected onConstruct():void {
		this.m_px = <fgui.GTextField>(this.getChildAt(2));
		this.m_py = <fgui.GTextField>(this.getChildAt(6));
		this.m_x = <fgui.GTextInput>(this.getChildAt(10));
		this.m_y = <fgui.GTextInput>(this.getChildAt(14));
	}
}